# Independent review of the Suffice 0.12 experiment harness

Review date: 2026-11-11, America/Chicago. Scope: read-only review of `scripts/benchmark_retention_v0_12.py` and `docs/retention_experiment_v0_12.md`, plus a small static schedule/count check. This review did not execute the native benchmark, compile code, or reproduce historical timings. Actual experiment results must come from the completed run and audit receipts.

## Result

**PASS after the author corrected two portable-audit path issues. No blocking scientific, identity, timer, oracle, replacement-model, scheduling, or paired-calculation issue remains in the reviewed version.**

Final reviewed identities:

| File | SHA-256 |
|---|---|
| `scripts/benchmark_retention_v0_12.py` | `2e8f78ae716163f8b52a6c1cd1326fc3fd8dcce5eaae2800d436c7782a4e596e` |
| `docs/retention_experiment_v0_12.md` | `c5209185ea1326880cbc3606e167a5cfb98171ceaa1c003960846a25324c277a` |

The implementation author made the requested corrections. The reviewer edited only this review and its earlier capture-review note. Changes after these identities are not automatically covered.

## Findings corrected before the measurement freeze

### R1 — Windows drive syntax could bypass the archive-relative path intent

The first `relative_file` implementation used `PurePosixPath` canonicality checks but did not reject colon-containing drive forms. Such a string can be relative under POSIX parsing while carrying drive semantics when joined by a native Windows `Path`.

The corrected resolver rejects backslashes, colons, ASCII control characters, and DEL; requires a canonical relative path; checks the base and each component for symbolic links; requires a regular file; and checks resolved containment. Fixed metadata files now also use this resolver, including suite/run files, original provenance, the measured build manifest, and an existing summary.

This correction does not change the ordinary frozen corpus or experiment design. It supports the stated portable local-file audit boundary. The checks assume a stable evidence directory; they are not a race-free hostile-filesystem capability implementation.

### R2 — Frozen-source inventory could dereference symbolic-link files

The initial frozen-source inventory used a comprehension over `is_file()` and hashed those paths. A symbolic link to a file can satisfy `is_file()` and cause an external target read.

The corrected inventory rejects a symbolic-link source root and symbolic-link/nonregular members, and hashes each regular source via `relative_file`. The input inventory already rejects symbolic links. The auditor no longer relies on the source hash alone to define the permitted read location.

## Code, binary, and input identity

`current_code` requires a passed nonsanitized native build with tests requested and passed, unchanged input snapshots, the correct project root, and an exact recorded catalog-binary hash/path match. It rehashes each compiled project input and separately includes the current Python client and experiment driver.

Preparation copies the exact 187-file input inventory and preserves the original 103-file source mapping without recapture or recompression. It verifies the source run's passed status and suite identity, copies original suite/run provenance, freezes all selected source files, and records the unchanged measured build manifest. The frozen compiled input map and the Python additions are explicit; compiler/SDK/shared-library information remains a recorded external scope, not a claim to reproduce the whole OS.

The run rechecks live sources, binary, manifest, and copied input identities at scenario-group boundaries and after completion. Every saved process record is hashed and associated with its exact schedule item. A failed or interrupted measurement is not resumed into a later successful run; the next attempt requires another directory.

The portable audit reconstructs these relationships from included relative files. The binary hash is reconciled with the retained build manifest; the audit does not claim to run a binary or independently prove that a build receipt is an authenticated external attestation.

## Oracle independence and output validation

The oracle reads preserved original source copies directly. It checks their recorded lengths and SHA-256 values, verifies the UTF-8 byte ordering and modulo-twelve partition, derives row positions independently by sorted project paths, and evaluates each of the three length predicates using actual body length.

It does not use the producer's feature table, native selection mask, or native digest to decide which rows should be returned. During measurement, `check_output` compares the row count and each row's ID, path, and complete byte string in order. It then records descriptors derived from the received output.

The later portable auditor compares saved row/path/length/digest descriptors with included original bytes. The documentation correctly distinguishes this from re-executing historical native output. Raw process records contain descriptors rather than every emitted hex body, so they support the stated retained-evidence audit, not an independent replay of historical execution.

## Result replacement model

The independent model uses `(project, threshold)` keys. This is sufficient for this particular experiment because each project has one fixed immutable generation, every request covers the full fixed range, and each threshold maps to one exact program string. It should not be generalized to mutable generations or arbitrary text-equivalent queries without extending the key.

For Populate misses, the model accounts for byte and entry limits, removes the complete oldest-first victim set, and records all victims. Hits advance recency. Bypass performs no lookup, admission, or hit accounting. Zero-byte results still count toward the entry limit.

Every request reconciles native hits, admissions, occupancy, capacities, cumulative misses/evictions, and completed-run counts. The expected result capacity uses 24 bytes per row descriptor plus plaintext and is checked against the actual reported capacity. A different ABI/allocation behavior fails this experiment's assumption instead of silently pretending that the budgets are equal.

Victim identities are independently reconstructed by the model; they are not native per-victim event telemetry. The resource checks also verify snapshot, metadata, plan, worker-entry, worker-byte, and result bounds at observed API boundaries. These checks do not establish a complete independent worker-LRU model or an allocator/RSS peak.

## Timer scope

The primary timer spans child creation through successful shutdown, including readiness, twelve full admissions, plan/worker work, Capture/Recompute, full JSON/hex output, Python decoding/materialization, STATS requests, and bookkeeping.

The subtracted quantity is explicitly timed **oracle/audit work**: full-output comparison, descriptor hashing, result-LRU checks, and resource checks. This is broader than only full-byte comparison. Both the implementation and documentation state that scope correctly. Raw wall time is preserved, and the summary also reports matched raw-wall ratios.

One-time evidence copying, initial oracle loading, live identity checks outside sessions, and writing process records after shutdown are outside the service timer. Untimed assertions and bookkeeping remain inside it. Summed audit durations and `raw wall - audit = service` are checked by the portable audit.

Subtracting observer work cannot reverse its effects on caches, allocators, or scheduling. Likewise the native phase diagnostics—including Capture's per-row clocks—do not isolate a causal uninstrumented copy cost. These qualifications are explicit and should remain in the release interpretation.

## Schedule and counts

The four Williams sequences are:

`(0,1,3,2)`, `(1,2,0,3)`, `(2,3,1,0)`, `(3,0,2,1)`.

A separate static check confirmed that each treatment appears once at each position and that all twelve ordered distinct adjacent pairs appear once across the four sequences. Eight repetitions use each sequence twice. Scenario order rotates across repetitions, and two-arm bypass order alternates.

| Scenario | Processes at eight repetitions | Requests |
|---|---:|---:|
| Reuse | 32 | 1,536 |
| Pressure | 32 | 832 |
| Mixed query | 32 | 2,304 |
| Bypass worker churn | 16 | 768 |
| Total expected | **112** | **5,440** |

These are verified design totals, not a claim that the run had completed at review time. The auditor requires the exact schedule, unique process observations, complete request inventories, and consistent counters.

The runner and each child share one verified permitted logical CPU. Affinity restoration is in the failure/success cleanup path and is itself checked. This is not exclusive CPU ownership, cache flushing, randomized hardware assignment, or native Windows execution.

## Paired calculations and interpretation

Series are indexed by `(scenario, repetition, variant)`, preserving the pairing. The script computes per-repetition ratios before aggregating them; it does not divide independently aggregated medians to claim a paired result.

- `Recompute/Capture > 1` favors Capture at a fixed worker budget.
- `Large/Tight > 1` favors the tight worker setting at a fixed strategy.
- `(Recompute_tight/Capture_tight)/(Recompute_large/Capture_large) > 1` means Capture's relative advantage grows under the tight setting.
- Corresponding raw-wall contrasts and interactions retain the effect of the audit-inclusive boundary.
- `1 - tight_observed_worker_peak/large_observed_worker_peak` is a retained-worker reduction, not an RSS reduction.

The ratios include their individual values, geometric means, medians, extrema, and direction counts. Eight process repetitions are the repeated observations for a contrast. The 5,440 requests are correlated work within those processes and are not independent performance trials. The observed range is not a confidence interval.

The scenarios remain separate. The document also identifies one corpus, three simple predicates, no generation mutation, no concurrent clients, shared Linux hardware, and component-budget rather than RSS evidence. This supports a controlled configuration comparison within the same 0.12 binary; it does not establish a comparison with old 0.11 timestamps, an application-wide 10× result, or Windows performance.

## Remaining execution gate

The code/design review permits the frozen run to proceed. The final report still requires the completed Release measurement records, successful portable audit, and the separately recorded native correctness/sanitizer evidence. No extra benchmark or heavyweight task was run by this reviewer while the owner prepared the measurement.
