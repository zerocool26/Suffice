# Independent audit of the Suffice 0.11 session evidence

**Result: passed within the stated evidence scope.** No counter, ratio, source-identity, cache-model, or timing-boundary inconsistency was found in the retained experiment. This was a read-only audit of existing source, original/copy inputs, frozen generations and process records. It did not run native executables, repeat a benchmark, generate new timing observations, or modify the measured script/results.

Audit time: 2026-11-12T02:51:04.053263+00:00. Exact hashes, per-process reconstructions and recomputed statistics are in [RESULT.json](RESULT.json).

## Independently confirmed counts and ratios

| Quantity | Recomputed value |
| --- | ---: |
| Fresh native process records | 24 |
| Complete-output checks recorded by the measured harness | 888 |
| Compared output rows | 6,504 |
| Compared plaintext bytes | 111,050,700 |
| Original source files / copied source files | 103 / 103 |
| Plaintext corpus bytes | 1,460,207 |
| Selected source files | 86 |
| Selected plaintext bytes | 1,455,100 |

These are **six process pairs per trace**. The 888 requests are repeated observations inside those processes; they are not 888 independent performance trials. The corpus is one predecessor-code inventory partitioned into twelve logical projects, not twelve independently sampled user projects.

For each pair, the ratio is `bypass service time / Populate service time`; a value above 1 favors Populate.

| Trace | Geometric mean of paired ratios | Median paired ratio | Observed minimum–maximum | Pairs favoring Populate |
| --- | ---: | ---: | ---: | ---: |
| Reuse | 1.0192424925 | 0.9814195289 | 0.9472624970–1.1822040481 | 2 / 6 |
| Pressure | 0.9050219369 | 0.8766888965 | 0.8284040236–1.0766546572 | 1 / 6 |

The reuse geometric mean being slightly above 1 does not establish a consistent benefit: four of the six paired observations favor bypass, and the median paired ratio is below 1. Pressure favors bypass in five of six pairs. The reciprocal of the pressure geometric mean is 1.1049455922, so the described approximately 1.105-times Populate service time is mathematically consistent. These are descriptive observations, not confidence intervals or a general cache-performance result.

All four recorded ratio families—service, raw session wall, complete-client query request, and native query time—were recomputed from each pair's original process record. Their geometric means, medians, minima and maxima match `SUMMARY.json`. Every reported policy median also matches a fresh median over the corresponding six process records. Dividing policy medians would answer a different aggregation question and was not used for the paired ratios.

## Timing boundary and arithmetic

Source inspection confirms that the raw session timer starts before native child creation and stops after successful shutdown. It includes readiness, twelve full native admissions, every query, planning, the actual Populate construction passes, complete native hex emission and pipe transfer, Python JSON/hex decoding and collected byte objects, statistics requests, control bookkeeping and closure.

Only the explicitly timed `check_output` section is subtracted. That section compares every row/order/path/body with the independent original data, verifies native output counters, and constructs the retained per-row SHA-256 descriptors. Each process's stored oracle duration equals the sum of its per-request comparison durations. Every process satisfies `service_ms = raw_session_wall_ms - summed oracle_validation_ms`. All retained request/native phase aggregates independently matched their component sums.

The initial readiness STATS is inside startup time. The separate `stats_request_ms` aggregate covers the post-admission STATS and each post-query STATS. Neither aggregate should be added to raw wall, because they are nested observations. The main service result already includes them.

This subtraction removes the measured time spent in the explicit validation section. It does not remove instrumentation's effects on memory/cache state, scheduling, or control flow. The method correctly describes an **instrumented complete-service measurement**, not a counterfactual measurement of an otherwise identical uninstrumented application.

Corpus copying/capture/packing is a separate one-time preparation observation of 389.470491 ms. Frozen-input hashing and original-oracle loading also occur outside the session timer. Thus the results include full native admissions and cache construction but do not represent capture-plus-service latency for a previously uncaptured project.

## Byte oracle and retained evidence

The audit re-enumerated the actual predecessor source directories using the stated suffix filter and UTF-8 path ordering. All 103 files match the recorded inventory and the zero-based index modulo twelve partition rule. Every original file was compared byte-for-byte with its preserved input copy, and both length and SHA-256 match the suite record.

Expected output descriptors were reconstructed from those bytes using only `len(data) > 1024` and independently sorted paths. All 888 requests' complete ordered row/path/length/SHA-256 descriptor lists match these reconstructed expectations. The audit also checked each generation's `CURRENT`, manifest digest, component sizes/digests, all rows metadata, and the feature column used by this predicate. Every OPEN's recorded row count, generation, revision, component-byte count and additional verified-body count agrees with those inputs.

The measured harness's source performs actual byte-for-byte body equality before creating each descriptor. This audit revalidated the retained descriptors and the code that produced them; it did not reproduce the actual byte transfers, because raw response bodies are not saved for every repetition. Native diagnostic FNV hashes are not used to determine expected output selection or byte equality.

The predicate selects approximately 83.4951% of files and 99.6503% of bytes. Almost all corpus plaintext therefore crosses the complete output boundary. This is a substantial limitation on interpreting a cache-compute benefit as an end-to-end client benefit.

## Cache state, trace order and budgets

An independent `OrderedDict` model with oldest-first removal reconstructed every request's byte-bounded LRU transition. It checked hit and admission flags, retained capacity, entry count, cumulative hit/admission/eviction counters, miss counters and direct decoded-byte counts after every query. It also checked the exact alternating AB/BA policy schedule, alternating trace order, fresh readiness state, all native option values, revision/sequence chronology, distinct process IDs and recorded affinity.

| Per-process Populate result | Reuse | Pressure |
| --- | ---: | ---: |
| Requests | 48 | 26 |
| Hits | 36 | 12 |
| Admissions | 12 | 14 |
| Evictions | 0 | 12 |
| Final retained result bytes | 1,457,164 | 283,059 |
| Multiple-victim admissions | 0 | 0 |

Bypass retains no result entries and reports no result-cache hits/admissions/evictions. The result-entry limit is 64; pressure is caused by the configured byte budget. All twelve projects fit the plan-entry limit, so these sessions do not separately stress plan eviction.

The protocol exposes eviction counts, retained sizes and future hit/admission outcomes. Specific victim identities are reconstructed by the reference LRU policy, not observed through a native victim-ID event. Every exposed state matched that model. Neither trace contains a multiple-victim event, publication update, invalidation or retired reader; those behaviors need their separate correctness evidence.

Every observed step retained 444,574 logical Snapshot bytes and 19,552 generation-metadata bytes, below the respective 64 MiB and 8 MiB configured limits. Final prepared-worker component storage is 1,693,703 bytes under both policies. That is a separately exposed component observation, not memory included in the snapshot or result caps. No process RSS or laptop-wide memory ceiling was measured.

The actual largest corpus file is 87,723 bytes, the largest partition has 173,566 plaintext bytes, and every partition has at most 9 rows. These are within the producer's recorded per-file, per-project and row bounds. Per-request output caps are the corresponding full partition dimensions, so the successful selected outputs did not depend on truncation.

## Provenance checked and remaining boundaries

The independent hash checks covered:

- All **48** current measured source files and their frozen copies.
- All **187** prepared input files, including source copies and catalog components.
- Both measured executables, matching the suite and build-manifest identities.
- The passed build manifest and its unchanged before/after input record.
- All **42** measured C++ source/header identities against the build manifest, including current catalog headers, loader, runtime and payload implementation.
- All **24** process-record hashes and the suite → run → summary hash relationships.

There are 44 measured files also present in the build manifest; the additional files are execution-time Python inputs rather than compiled C++ inputs. This audit found no stale native/header/payload association. The build record explicitly leaves compiler-default system headers/libraries outside its content hashes. Matched provenance is not a hermetic rebuild or cryptographic attestation of historical execution.

The host is Linux; native Windows behavior and performance remain unmeasured. Python and its child share one permitted logical CPU, without exclusive ownership of that CPU. Filesystem page caches are not flushed, and pre-pair identity checking may warm the inputs. The six pairs per trace cover only one fixed corpus, one predicate and two chosen request traces. No production query distribution, daily project mutation pattern, representative storage contention or general speedup is established.

The frozen benchmark's original `summarize` path still expects the historic absolute predecessor source path. This audit used that currently available source to check original/copy equality. A separate relocation-aware archive auditor is being supplied by the implementation owner; it is outside this audit's executed scope. Portable archive checks can establish agreement with included copied bytes without claiming a fresh comparison to unavailable original external paths.

## Audited references

- [Retained suite](../catalog_sessions_v0_11/suite.json)
- [Run inventory](../catalog_sessions_v0_11/RUN.json)
- [Original summary](../catalog_sessions_v0_11/SUMMARY.json)
- [Measured benchmark source](../catalog_sessions_v0_11/measurement_source/scripts/benchmark_catalog_v0_11.py)
- [Session methodology](../../docs/catalog_session_method_v0_11.md)
- [Independent recomputation result](RESULT.json)
