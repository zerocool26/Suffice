# Suffice Auditable Artifact Reuse

*Complete session costs and ownership limits for local developer agent tools*

## Abstract

Repository tools for local coding agents must preserve correct project state while controlling retained data, prepared computations, and cached output. A faster cache hit alone does not establish a faster useful session. We present Suffice, a deterministic C++ and Python artifact runtime with immutable generations, exact output identity, semantic admission checks, and explicit retention budgets. We compare complete-result population with bypass in a persistent catalog over two fixed traces, using 103 source files partitioned into twelve logical projects. Across 24 processes, 888 requests return outputs checked against independent original bytes. Cache population does not consistently improve the reuse trace and increases paired geometric service time by approximately 10.5% under scan pressure. Retained worker components exceed logical snapshot inputs by approximately 3.8 times. An accompanying verification notebook preserves inputs, measured sources, observations, and an offline auditor. The contribution is an inspectable systems resource and a bounded empirical result; no language-model capability or software-issue resolution improvement is claimed.

## 1 Introduction

Coding agents interact with repositories through tools that read, select, transform, and retain artifacts. SWE-agent demonstrates that these interfaces affect agent behavior [1]. Their implementation also determines what bytes reach the consumer, which project version those bytes describe, and how much state survives between requests. These concerns become significant when several projects share a constrained machine.

We investigate three questions. What state must identify an exact reusable result? Which owners must remain charged after a project update? Does complete-result caching repay construction and output-delivery costs over a session?

Suffice provides a small experimental substrate for these questions. It captures files, verifies their derived features against original bodies, and serves integer predicates through one persistent native process. Its contribution combines explicit observable-output and ownership contracts, failure-focused regressions, and a frozen complete-service experiment. Hashes, leases, immutable snapshots, and least-recently-used replacement are established mechanisms; we do not claim to invent them.

The intended application is a repository-tool backend for local developer agents. The present study isolates that backend. It includes no Gemma inference, fine-tuning, autonomous patching, or SWE-bench evaluation. Integrating the resource with an agent and measuring task success remains separate work.

For example, a repository-reading tool could pin a generation, select bounded artifacts, and return their paths and complete bodies. Later reads through that lease would describe the same captured version even after an update. This proposed integration exposes version consistency to the agent; its effect on agent behavior is not evaluated here.

## 2 Related work

SWE-agent studies an agent-computer interface for repository navigation, editing, and execution [1]. SWE-bench evaluates resolution of real repository issues [2]. Our output comparisons establish deterministic service behavior, not solved developer tasks.

CloudBuild already applies content-based caching across build languages under a file-I/O contract [3]. Build Systems à la Carte separates scheduling from rebuilding decisions and explains dependency traces [4]. Suffice supplies generation-level artifact reuse; it neither discovers compiler dependencies nor establishes that arbitrary build outputs remain valid.

Einziger et al. extend TinyLFU to variable-sized objects, including an admission policy that compares a candidate with the aggregate victims needed to make space [5]. Suffice currently uses byte LRU with an entry cap. The experiment exposes construction and displacement costs but does not evaluate TinyLFU or a new admission algorithm.

Our narrower contribution is a reusable correctness and accounting contract, executable failure cases, and an auditable negative result about complete-result population in the measured service.

## 3 Runtime methods

### 3.1 Capture and semantic admission

The producer captures regular files from a selected tree, excludes configured build/dependency directories, and preserves exact UTF-8 relative paths. Each row contains original bytes and four signed-integer features: byte length, versioned extension class, LF-byte count, and validity as UTF-8 without NUL. Empty bytes satisfy the last feature. Paths are sorted by encoded bytes; row IDs belong to that generation.

A generation contains raw and packed features, independently indexed Zstandard payload frames, row metadata, and component lengths and SHA-256 hashes. Every capture rehashes admitted contents. Identical paths, bodies, and features reuse the current generation without recompression, even after timestamp-only changes. A changed generation currently recompresses all admitted bodies.

Native disk admission checks component integrity, canonical paths, sorted uniqueness, payload structure, raw/packed agreement, decoded lengths, and body hashes. It independently re-derives all four features. A regression changes a feature, rebuilds its packed representation and payload binding, and refreshes component hashes; admission still rejects the false feature. Thus internally consistent metadata is not treated as proof of semantic truth. Direct C++ publication relies on its caller for these external semantics.

The current disk loader performs two full decode passes: Full Snapshot validation followed by body/feature verification. Both are charged to admission. Checked individual reads and repeated inventories do not create a cross-file transaction; coherent capture requires a quiescent source.

### 3.2 Identity and ownership

The observable result is an ordered sequence of generation-local row IDs, relative paths, and complete original bytes. A complete-result key includes generation ownership, all predicate-source bytes, and the requested global range. Matching dimensions, row numbers, or similar predicates cannot substitute for that identity.

Publication requires an expected native revision. Successful publication and deletion advance revisions; bounded deletion records prevent a stale expected-absent operation from succeeding after creation followed by deletion. Disk generation labels and native revisions have distinct scopes.

A lease retains one immutable generation. Replacing a project invalidates its automatic reuse while old leases continue returning old output. Snapshot accounting includes current generations, retired leases, and external shared owners. Shared snapshot inputs are charged once; generation metadata is charged separately. Publication conservatively requires headroom for old and new ownership before changing active state.

Retired-lease queries use temporary preparation and do not create fresh retained plans or results. This prevents an old query from leaving hidden internal owners after the caller releases its lease. Catalog operations require caller serialization; this is not a concurrent execution guarantee.

### 3.3 Retention and publication

Default native limits are 256 MiB for logical snapshot inputs, 32 MiB for generation metadata, and 64 MiB for complete results. Separate caps allow 32 project-name slots, including deletion records, 32 prepared plans, 512 KiB of plan text, and 64 result entries. Worker components and result-key bytes are reported separately. These pools are not a total resident-memory ceiling: temporary buffers, query structures, consumer objects, allocator overhead, and OS caches remain distinct.

The producer defaults to 1 MiB per admitted file, 128 MiB decoded capture, 1 GiB of retained files, and at most sixteen generations per store. Abandoned stages count toward disk limits. Historical generations are not automatically deleted; unchanged capture remains possible at capacity.

Disk publication builds an immutable generation and replaces the CURRENT pointer under a writer lock. A corrected failure case handles replacement succeeding immediately before an interruption: cleanup rereads CURRENT and preserves a candidate that is current or cannot safely be classified. Tests exercise an actual replacement followed by interruption and an unreadable pointer during cleanup. These are process-interruption checks, not power-loss durability tests.

## 4 Experimental design

### 4.1 Corpus and policies

The corpus contains 103 preserved predecessor source files with .cpp, .hpp, .py, and .suf extensions, totaling 1,460,207 plaintext bytes. Lexically sorted files are assigned round-robin to twelve logical projects of eight or nine files. These are partitions of one real code corpus, not twelve independently sampled repositories. Original paths and exact copies are retained.

The predicate selects files longer than 1,024 bytes: 86 files containing 1,455,100 bytes, or 99.65% of plaintext. The oracle reads original bodies and applies byte length directly, independently of packed features. Every returned row, path, length, and byte is checked after every request.

Both policies keep the native process alive and reuse prepared plans. Bypass computes without retaining complete results. Populate first delivers the computed output, then runs the existing two-pass cache builder; later hits replay complete output. Construction stays inside the request. Oversized results can execute without retention. This comparison isolates result policy, not persistence versus process restart.

The reuse trace executes four cycles through all twelve projects: 48 requests with a 1,457,164-byte result budget sufficient for all selected results. The pressure trace repeats hot projects zero and one for four pairs, scans projects two through eleven once, then repeats the hot pair four times: 26 requests with a 283,059-byte budget sufficient for the hot results together.

### 4.2 Timing and analysis

Each trace has six fresh-process pairs. Policy order alternates AB/BA; trace order also alternates. The harness and child share one permitted pinned logical CPU on an AMD EPYC 9V74 Linux host, without exclusive CPU ownership. Filesystem caches are not flushed. The recorded toolchain includes GCC 14.2, Python 3.12, Python zstandard 0.25.0, and codec 1.5.7.

The primary measurement is instrumented service time:

$$
T_{\mathrm{service}}=T_{\mathrm{session\ wall}}-T_{\mathrm{explicit\ oracle}}.
$$

It includes startup/readiness, twelve Full admissions, preparation, execution, cache construction, complete JSON/hex output, pipe transfer, Python decoding/materialization, statistics requests, bookkeeping, and shutdown. Only explicitly timed post-request comparison and digest work is subtracted. Raw wall times remain available. Subtraction does not undo the observer's effects on cache state or scheduling. One-time copying, capture, and packing took 389.470 ms and is reported separately.

Ratios divide Bypass by Populate within the same pair; above one favors Populate. We report paired geometric means, paired medians, observed ranges, and direction counts. The six pairs per trace are the timing observations. The 888 requests are not independent performance trials, and the ranges are not confidence intervals.

## 5 Results

All 888 complete-output checks passed across 24 processes, covering 6,504 rows and 111,050,700 compared plaintext bytes.

| Trace | Paired geometric ratio | Paired median ratio | Pairs favoring Populate |
|---|---:|---:|---:|
| Reuse | 1.01924 | 0.98142 | 2 of 6 |
| Pressure | 0.90502 | 0.87669 | 1 of 6 |

Reuse ratios span 0.94726-1.18220. Its slightly favorable geometric mean does not establish consistent improvement: four pairs and the paired median favor Bypass. Pressure ratios span 0.82840-1.07665; five pairs favor Bypass. The reciprocal geometric ratio corresponds to approximately 10.5% higher Populate service time on this trace.

Separate policy medians provide scale:

| Trace | Bypass service | Populate service | Populate construction |
|---|---:|---:|---:|
| Reuse | 77.594 ms | 81.079 ms | 4.098 ms |
| Pressure | 51.954 ms | 61.253 ms | 5.008 ms |

Dividing these separate medians does not recover the paired geometric ratios. Reuse records 36 hits, twelve admissions, and no evictions. Pressure records twelve hits, fourteen admissions, and twelve evictions. The scan displaces both hot results, which are rebuilt on return. A separate LRU model reconciles outcomes, counts, and retained bytes; victim identities are reconstructed rather than emitted by native events. Multiple-victim eviction is covered separately by correctness tests, not by these traces.

Both policies retain 444,574 logical snapshot input bytes, 19,552 metadata bytes, and 1,693,703 worker-component bytes across twelve plans. Workers therefore charge approximately 3.8 times the logical inputs. All reported retention bounds hold; these figures are component accounting, not process RSS.

## 6 Interpretation and limitations

Cache construction must be repaid by later reuse. Under constant per-request costs, with no eviction or invalidation, let K be the total number of identical requests, D direct cost, R replay cost, and C construction cost. Populate breaks even when:

$$
D+C+(K-1)R\le KD,\qquad
K\ge 1+\left\lceil\frac{C}{D-R}\right\rceil\quad(D>R).
$$

The first request executes normally. Eviction, updates, and competing entries can prevent the required future hits. Because this predicate selects almost all plaintext, cached output still incurs substantial delivery work. The measured results justify leaving population explicit; default Use can replay an existing entry but does not construct one on a miss.

The worker footprint motivates separate retention control or lazy preparation. Size-aware admission can compare a candidate with the aggregate victims needed to make space [5]. Our measured construction costs motivate also charging the work required to create that candidate. Neither improvement is implemented or measured here.

External validity is limited by one corpus, one predicate, two traces, six pairs per trace, and one Linux configuration. The experiment has no project updates or concurrent clients. It does not compare against filesystem reads, SQLite, Bazel, CloudBuild, or alternative cache policies, and cannot establish general superiority. Consumer-laptop performance, native Windows behavior, peak RSS, physical disk allocation, agent token usage, and software-task success are unmeasured. Generation integrity also does not supply the dependency contract needed for compiler-output reuse [4].

## 7 Verification and reproducibility

Release and ASan/UBSan builds each passed nine recorded checks with stable compiled inputs. Native catalog checks include eighteen groups and eight injected allocation failures. Producer checks cover 22 cases; integration rejects fourteen corrupted generations in each build. Coverage counts overlap. Leak detection was disabled; these checks are not a formal proof or external peer review.

The accompanying verification notebook embeds 187 input files, 48 frozen measured sources, 24 process records, twelve generation manifests, the measured build manifest, and a standard-library auditor. It checks included original bytes, feature derivation, recorded descriptors, LRU transitions, timing arithmetic, and paired statistics without downloading data or invoking a model. It verifies retained evidence; it does not re-execute historical native output or decompress payload frames. Full native reruns require the documented compiler/codec environment. The original experiment performed complete byte equality, while the portable auditor checks saved descriptors against original copies.

AI assistance was used for implementation, analysis, source discovery, and drafting. The measured runtime and checks execute deterministic C++/Python. No Gemma results, competition-dataset results, model training, or model capability measurements are reported. Literature mechanisms are attributed above; the new resource and its limited observations are presented separately from future hypotheses.

## 8 Conclusion

Suffice makes artifact reuse inspectable through exact output identity, live-owner accounting, semantic admission, and complete-service measurements. In the retained workload, complete-result population does not consistently improve reuse sessions and is usually slower under scan pressure. Prepared workers also outweigh logical snapshot inputs. These observations establish a concrete baseline for evaluating selective admission and worker retention before adding them to local developer-agent tooling.

## References

[1] J. Yang, C. E. Jimenez, A. Wettig, K. Lieret, S. Yao, K. Narasimhan, and O. Press. SWE-agent: Agent-Computer Interfaces Enable Automated Software Engineering. NeurIPS, 2024. https://doi.org/10.52202/079017-1601

[2] C. E. Jimenez, J. Yang, A. Wettig, S. Yao, K. Pei, O. Press, and K. Narasimhan. SWE-bench: Can Language Models Resolve Real-World GitHub Issues? ICLR, 2024. https://arxiv.org/abs/2310.06770

[3] H. Esfahani et al. CloudBuild: Microsoft's Distributed and Caching Build Service. ICSE Companion, 2016. https://doi.org/10.1145/2889160.2889222

[4] A. Mokhov, N. Mitchell, and S. Peyton Jones. Build systems à la carte: Theory and practice. Journal of Functional Programming 30, e11, 2020. https://doi.org/10.1017/S0956796820000088

[5] G. Einziger, O. Eytan, R. Friedman, and B. Manes. Lightweight Robust Size Aware Cache Management. arXiv:2105.08770v2, 2021. https://arxiv.org/abs/2105.08770v2
