#!/usr/bin/env python3
"""Persistent native artifact-catalog client and JSONL job runner.

Keep one CatalogProcess alive for a session to amortize admission and planning.
The native service is a child process using stdin/stdout, with no network port.
Artifact output is bounded by caller-supplied row/byte limits. Its memory is
separate from native retained-snapshot and result-cache budgets.
"""
from __future__ import annotations
import argparse
import json
from pathlib import Path
import subprocess
import sys
import time


class CatalogError(RuntimeError):
    def __init__(self, result, rows=()):
        super().__init__(result.get("error", "catalog request failed"))
        self.result = result
        self.rows = list(rows)


def _hex(value):
    if not isinstance(value, str) or "\0" in value:
        raise ValueError("protocol text must be a NUL-free string")
    return value.encode("utf-8", errors="strict").hex()


def _uint(value):
    if type(value) is not int or not 0 <= value <= (1 << 64) - 1:
        raise ValueError("protocol integer must be uint64")
    return str(value)


class CatalogProcess:
    def __init__(self, binary, *, native_options=()):
        self.binary = str(Path(binary).resolve())
        self.process = subprocess.Popen([self.binary, "serve", *map(str, native_options)],
                                        stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                                        stderr=subprocess.PIPE)
        self.sequence = 0
        self.closed = False
        self.active = False

    def __enter__(self):
        return self

    def __exit__(self, kind, value, traceback):
        self.close(force=kind is not None)

    def request(self, fields, *, collect=True, on_row=None):
        if self.closed:
            raise RuntimeError("catalog process is closed")
        if self.active:
            raise RuntimeError("catalog client requests are not reentrant")
        wire = ("\t".join(fields) + "\n").encode("ascii")
        if len(wire) > (256 << 10) + 1:
            raise ValueError("request exceeds native protocol line limit")
        self.sequence += 1
        started = time.perf_counter()
        rows = []
        terminal_error = False
        self.active = True
        try:
            self.process.stdin.write(wire)
            self.process.stdin.flush()
            while True:
                # Default admitted rows are <=1MiB; allow JSON/path overhead.
                line = self.process.stdout.readline((4 << 20) + 1)
                if not line:
                    error = self.process.stderr.read(8192).decode("utf-8", "replace")
                    raise RuntimeError("native catalog exited before result: " + error)
                if len(line) > 4 << 20 or not line.endswith(b"\n"):
                    raise RuntimeError("native response line exceeds client limit")
                event = json.loads(line)
                if event.get("seq") != self.sequence:
                    raise RuntimeError("native response sequence mismatch")
                if event.get("type") == "row":
                    row = {"row": event["row"],
                           "path": bytes.fromhex(event["path_hex"]).decode("utf-8"),
                           "data": bytes.fromhex(event["data_hex"])}
                    if collect:
                        rows.append(row)
                    if on_row is not None:
                        on_row(row)
                elif event.get("type") == "result":
                    event["client_wall_ms"] = (time.perf_counter() - started) * 1000
                    if event.get("status") != "ok":
                        terminal_error = True
                        raise CatalogError(event, rows)
                    return event, rows
                else:
                    raise RuntimeError("unknown native response type")
        except CatalogError:
            # Only a native terminal error leaves the protocol synchronized.
            # A callback can raise this same exception type before that point.
            if not terminal_error:
                self.close(force=True)
            raise
        except BaseException:
            # An interrupted callback or malformed response must not leave the
            # next request consuming a previous request's rows.
            self.close(force=True)
            raise
        finally:
            self.active = False

    def state(self, project):
        return self.request(["STATE", _hex(project)])[0]

    def open(self, project, catalog_root, *, expected_revision):
        return self.request(["OPEN", _hex(project), _hex(str(Path(catalog_root).resolve())),
                             _uint(expected_revision)])[0]

    def pin(self, alias, project):
        return self.request(["PIN", _hex(alias), _hex(project)])[0]

    def unpin(self, alias):
        return self.request(["UNPIN", _hex(alias)])[0]

    def run(self, project, program, *, first=0, count=None, cache="use", emit="hex",
            max_rows=1 << 20, max_bytes=16 << 20, pinned=False, collect=True, on_row=None):
        if cache not in {"bypass", "use", "populate"} or emit not in {"hex", "hash"}:
            raise ValueError("invalid cache or emit mode")
        return self.request(["RUNPIN" if pinned else "RUN", _hex(project), _hex(program),
                             _uint(first), "all" if count is None else _uint(count), cache,
                             emit, _uint(max_rows), _uint(max_bytes)], collect=collect, on_row=on_row)

    def drop(self, project, *, expected_revision):
        return self.request(["DROP", _hex(project), _uint(expected_revision)])[0]

    def stats(self):
        return self.request(["STATS"])[0]

    def clear(self, target="all"):
        if target not in {"results", "workers", "plans", "all"}:
            raise ValueError("invalid clear target")
        return self.request(["CLEAR", target])[0]

    def close(self, force=False):
        if self.closed:
            return
        try:
            if not force and self.process.poll() is None:
                self.request(["QUIT"])
        except Exception:
            force = True
        finally:
            self.closed = True
            if force and self.process.poll() is None:
                self.process.kill()
            try:
                self.process.wait(timeout=10)
            except subprocess.TimeoutExpired:
                self.process.kill()
                self.process.wait()
            for stream in (self.process.stdin, self.process.stdout, self.process.stderr):
                stream.close()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--binary", type=Path, required=True)
    parser.add_argument("--jobs", type=Path, required=True,
                        help="JSONL operations: open,run,state,pin,unpin,drop,stats,clear")
    parser.add_argument("--max-snapshot-bytes", type=int, default=256 << 20)
    parser.add_argument("--max-cache-bytes", type=int, default=64 << 20)
    args = parser.parse_args()
    if args.jobs.stat().st_size > 8 << 20:
        parser.error("job file exceeds 8MiB")
    native = ["--max-snapshot-bytes", _uint(args.max_snapshot_bytes),
              "--max-cache-bytes", _uint(args.max_cache_bytes)]

    def output_row(row):
        print(json.dumps({"type": "row", "row": row["row"], "path": row["path"],
                          "data_hex": row["data"].hex()}, ensure_ascii=True), flush=True)

    failed = False
    with CatalogProcess(args.binary, native_options=native) as catalog:
        with args.jobs.open("rb") as stream:
            for index, raw in enumerate(stream, 1):
                if not raw.strip():
                    continue
                try:
                    job = json.loads(raw)
                    if not isinstance(job, dict):
                        raise ValueError("job must be an object")
                    op = job.pop("op")
                    if op == "open":
                        result = catalog.open(**job)
                    elif op == "run":
                        if "program_file" in job:
                            p = Path(job.pop("program_file"))
                            if p.stat().st_size > 64 << 10:
                                raise ValueError("program exceeds64KiB")
                            job["program"] = p.read_text(encoding="utf-8")
                        result, _ = catalog.run(**job, collect=False, on_row=output_row)
                    elif op in {"state", "pin", "unpin", "drop", "stats", "clear"}:
                        result = getattr(catalog, op)(**job)
                    else:
                        raise ValueError("unknown job op")
                    print(json.dumps({"job": index, **result}), flush=True)
                except CatalogError as error:
                    failed = True
                    print(json.dumps({"job": index, **error.result}), flush=True)
                except (ValueError, TypeError, KeyError, OSError) as error:
                    failed = True
                    print(json.dumps({"job": index, "status": "error", "error": str(error)}), flush=True)
    return int(failed)


if __name__ == "__main__":
    sys.exit(main())
